# =============================================================================
#  CADTR Lambda Sweep Parallel -- "Hero Graph" & Table 3 Generator
#  Purpose: Run 30 replications in parallel, outputting mean, SD, CI, and p-values
# =============================================================================

import csv
import sys
import numpy as np
from dataclasses import replace
from pathlib import Path
from typing import List, Dict, Any
import multiprocessing
from scipy import stats as sp_stats

from Configurations import (
    Arrival_Config,
    Simulation_Config,
)
from Core.Simulator import Simulator
from Metrics.Collector import MetricsCollector
from Models.Distributions import (
    Exponential_Interarrival,
    Lognormal_Service_Times,
    Trace_Service_Times,
    EWMA_Service_Time_Estimator,
)
from Models.Policies import (
    CADTR_Policy,
    Expected_Utility_Oracle_Policy,
    FTCPolicy,
    Mode_Aware_Baseline_Policy,
    TTL_Feasibility_Bang_Bang_Policy,
)
from Models.Utility import CADTR_Mission_Utility
from Core.Task import Mode

# ── Sweep configuration ─────────────────────────────────────────────────
LAMBDA_VALUES = [0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19]
PRIORITY_RATE = 0.25          # 25% critical tasks ("threat-burst" ratio)
CADTR_SAFETY_BUFFER = -0.20   # Tighter buffer for stress test
NUM_REPLICATIONS = 30
SEED_BASE = 42

POLICY_DEFS = {
    "CADTR": "cadtr",
    "Myopic CDF Oracle": "cdf_oracle",
    "Mode-Aware Oracle": "mode_aware",
    "F-BB": "f_bb",
    "FTC*": "ftc_star",
}

# ── Helper: classify tasks by priority ───────────────────────────────────
def _task_missed(task) -> int:
    if task.dropped_in_queue_bool:
        return 1
    if task.completion_time_f64_opt is None:
        return 1
    return 1 if float(task.completion_time_f64_opt) > float(task.deadline) else 0

def _priority_class_stats(metrics: MetricsCollector) -> Dict[str, Any]:
    all_tasks = (
        list(metrics.completed_tasks_list_task)
        + list(metrics.dropped_tasks_list_task)
        + list(metrics.unfinished_tasks_list_task)
    )
    premium = [t for t in all_tasks if bool(getattr(t, "high_priority_bool", False))]
    standard = [t for t in all_tasks if not bool(getattr(t, "high_priority_bool", False))]

    def _miss_rate(tasks):
        if not tasks:
            return 0.0
        return float(np.mean([_task_missed(t) for t in tasks]))

    def _mean_utility(tasks, util_model):
        if not tasks:
            return 0.0
        return float(np.mean([util_model.Utility(t) for t in tasks]))

    def _slow_frac(tasks):
        slow = sum(1 for t in tasks if t.chosen_mode_mode_opt == Mode.SLOW)
        total = sum(1 for t in tasks if t.chosen_mode_mode_opt in (Mode.SLOW, Mode.FAST))
        return float(slow / total) if total > 0 else 0.0

    util_model = metrics.utility_model_utility_model
    return {
        "premium_miss_rate": _miss_rate(premium),
        "standard_miss_rate": _miss_rate(standard),
        "overall_miss_rate": _miss_rate(all_tasks),
        "premium_utility": _mean_utility(premium, util_model),
        "standard_utility": _mean_utility(standard, util_model),
        "overall_utility": _mean_utility(all_tasks, util_model),
        "premium_n": len(premium),
        "standard_n": len(standard),
        "premium_slow_frac": _slow_frac(premium),
        "standard_slow_frac": _slow_frac(standard),
    }

# ── Build service model from config ─────────────────────────────────────
def _build_service_model(sim_config: Simulation_Config):
    service_cfg = sim_config.service_config
    source = str(service_cfg.service_time_source).lower()
    if source == "trace":
        base = Trace_Service_Times(
            csv_path_str=service_cfg.trace_csv_path_str,
            fast_latency_column_str=service_cfg.trace_fast_column_str,
            slow_latency_column_str=service_cfg.trace_slow_column_str,
            drop_error_rows_bool=service_cfg.trace_drop_error_rows_bool,
            prompt_type_filter_opt=service_cfg.trace_prompt_type_filter_opt,
        )
    elif source == "lognormal":
        base = Lognormal_Service_Times(
            slow_mu_f64=service_cfg.slow_logn_mu_f64,
            slow_sigma_f64=service_cfg.slow_logn_sigma_f64,
            fast_mu_f64=service_cfg.fast_logn_mu_f64,
            fast_sigma_f64=service_cfg.fast_logn_sigma_f64,
        )
    else:
        raise ValueError(f"Unknown service_time_source: {source}")

    if service_cfg.ewma_enabled_bool:
        return EWMA_Service_Time_Estimator(
            base_model=base,
            alpha_f64=service_cfg.ewma_alpha_f64,
            warmup_count_i32=service_cfg.ewma_warmup_count_i32,
        )
    return base

# ── Build policy by key ──────────────────────────────────────────────────
def _build_policy(key: str, policy_cfg, service_model):
    if key == "cadtr":
        return CADTR_Policy(
            cfg=policy_cfg,
            service_model=service_model,
            priority_safety_buffer_f64=CADTR_SAFETY_BUFFER,
        )
    elif key == "cdf_oracle":
        return Expected_Utility_Oracle_Policy(
            cfg=policy_cfg,
            service_model=service_model,
        )
    elif key == "mode_aware":
        return Mode_Aware_Baseline_Policy(
            cfg=policy_cfg,
            service_model=service_model,
        )
    elif key == "f_bb":
        return TTL_Feasibility_Bang_Bang_Policy(
            cfg=policy_cfg,
            service_model=service_model,
        )
    elif key == "ftc_star":
        return FTCPolicy(
            cfg=policy_cfg,
            service_model=service_model,
        )
    else:
        raise ValueError(f"Unknown policy key: {key}")

def run_single_simulation(args) -> Dict[str, Any]:
    lam, policy_label, policy_key, rep_idx = args
    seed = SEED_BASE + rep_idx
    
    sim_config = Simulation_Config(
        seed_i32=seed,
        priority_task_rate_f64=PRIORITY_RATE,
        arrival_config=Arrival_Config(lambda_rate_f64=lam),
    )

    service_model = _build_service_model(sim_config)
    interarrival = Exponential_Interarrival(lam)

    utility_rng = np.random.default_rng(sim_config.seed_i32 + 2000)
    utility_model = CADTR_Mission_Utility(
        cfg_utility_config=sim_config.utility_config,
        rng_opt=utility_rng,
    )

    metrics = MetricsCollector(
        utility_model_utility_model=utility_model,
        warmup_time_f64=sim_config.warmup_time_f64,
    )

    policy = _build_policy(policy_key, sim_config.policy_config, service_model)

    sim = Simulator(
        sim_config,
        interarrival,
        service_model,
        policy,
        metrics,
    )
    sim.Initialize()
    sim.Run()

    stats = _priority_class_stats(metrics)
    stats.update({
        "lambda": lam,
        "policy": policy_label,
        "replication": rep_idx,
    })
    return stats

def main():
    tasks = []
    for lam in LAMBDA_VALUES:
        for policy_label, policy_key in POLICY_DEFS.items():
            for rep in range(NUM_REPLICATIONS):
                tasks.append((lam, policy_label, policy_key, rep))

    print(f"Total tasks to run: {len(tasks)}")
    
    num_cores = multiprocessing.cpu_count()
    print(f"Using process pool with {num_cores} workers...")
    
    with multiprocessing.Pool(num_cores) as pool:
        results = pool.map(run_single_simulation, tasks)
        
    print("Simulations finished. Processing stats...")
    
    # Group results by (lambda, policy)
    grouped: Dict[tuple, List[Dict[str, Any]]] = {}
    for r in results:
        key = (r["lambda"], r["policy"])
        if key not in grouped:
            grouped[key] = []
        grouped[key].append(r)
        
    out_dir = Path("Results") / "lambda_sweep"
    out_dir.mkdir(parents=True, exist_ok=True)
    
    raw_csv_path = out_dir / "lambda_sweep_parallel_raw.csv"
    with open(raw_csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)
        
    stats_headers = [
        "lambda", "policy",
        "premium_miss_rate_mean", "premium_miss_rate_std", "premium_miss_rate_ci95",
        "standard_miss_rate_mean", "standard_miss_rate_std", "standard_miss_rate_ci95",
        "overall_miss_rate_mean", "overall_miss_rate_std", "overall_miss_rate_ci95",
        "premium_utility_mean", "premium_utility_std", "premium_utility_ci95",
        "standard_utility_mean", "standard_utility_std", "standard_utility_ci95",
        "overall_utility_mean", "overall_utility_std", "overall_utility_ci95",
        "premium_slow_frac_mean", "premium_slow_frac_std",
        "standard_slow_frac_mean", "standard_slow_frac_std"
    ]
    
    stats_rows = []
    for key, rep_list in grouped.items():
        lam, policy = key
        
        row = {"lambda": lam, "policy": policy}
        for metric in ["premium_miss_rate", "standard_miss_rate", "overall_miss_rate", 
                       "premium_utility", "standard_utility", "overall_utility",
                       "premium_slow_frac", "standard_slow_frac"]:
            vals = [r[metric] for r in rep_list]
            mean_val = np.mean(vals)
            std_val = np.std(vals, ddof=1) if len(vals) > 1 else 0.0
            ci_val = 1.96 * std_val / np.sqrt(NUM_REPLICATIONS)
            
            row[f"{metric}_mean"] = mean_val
            row[f"{metric}_std"] = std_val
            if f"{metric}_ci95" in stats_headers:
                row[f"{metric}_ci95"] = ci_val
                
        stats_rows.append(row)
        
    stats_csv_path = out_dir / "lambda_sweep_parallel_stats.csv"
    with open(stats_csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=stats_headers)
        writer.writeheader()
        writer.writerows(stats_rows)
        
    print(f"Stats written to {stats_csv_path}")
    
    # Run Paired t-test at lambda = 0.11
    cadtr_prem_mr = [r["premium_miss_rate"] for r in results if r["lambda"] == 0.11 and r["policy"] == "CADTR"]
    cdf_prem_mr = [r["premium_miss_rate"] for r in results if r["lambda"] == 0.11 and r["policy"] == "Myopic CDF Oracle"]
    ma_prem_mr = [r["premium_miss_rate"] for r in results if r["lambda"] == 0.11 and r["policy"] == "Mode-Aware Oracle"]
    fbb_prem_mr = [r["premium_miss_rate"] for r in results if r["lambda"] == 0.11 and r["policy"] == "F-BB"]
    
    print("\n" + "="*80)
    print("PAIRED T-TEST RESULTS AT LAMBDA = 0.11 (Premium Miss Rate)")
    print("="*80)
    
    t_stat_cdf, p_val_cdf = sp_stats.ttest_rel(cadtr_prem_mr, cdf_prem_mr)
    print(f"CADTR vs Myopic CDF Oracle: t = {t_stat_cdf:.4f}, p = {p_val_cdf:.4e}")
    
    t_stat_ma, p_val_ma = sp_stats.ttest_rel(cadtr_prem_mr, ma_prem_mr)
    print(f"CADTR vs Mode-Aware Oracle: t = {t_stat_ma:.4f}, p = {p_val_ma:.4e}")

    t_stat_fbb, p_val_fbb = sp_stats.ttest_rel(cadtr_prem_mr, fbb_prem_mr)
    print(f"CADTR vs F-BB: t = {t_stat_fbb:.4f}, p = {p_val_fbb:.4e}")
    
    print("\n" + "="*80)
    print("TABLE 3 REPRESENTATIVE SUMMARY (lambda = 0.03, 0.11, 0.19)")
    print("="*80)
    for target_lam in [0.03, 0.11, 0.19]:
        print(f"\nLambda = {target_lam}:")
        for p in POLICY_DEFS.keys():
            r_stats = next(r for r in stats_rows if r["lambda"] == target_lam and r["policy"] == p)
            print(f"  {p:25s} | "
                  f"Crit MR: {r_stats['premium_miss_rate_mean']*100:5.2f}% ± {r_stats['premium_miss_rate_ci95']*100:5.2f}% | "
                  f"Ovr MR: {r_stats['overall_miss_rate_mean']*100:5.2f}% ± {r_stats['overall_miss_rate_ci95']*100:5.2f}% | "
                  f"Ovr Util: {r_stats['overall_utility_mean']:.3f} ± {r_stats['overall_utility_ci95']:.3f}")

if __name__ == "__main__":
    main()
